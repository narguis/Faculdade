int somafrac(int n){
    float s = (1/2) + (1/3);

}